import { account } from "../../../appwrite/config";

export class AuthService {
    
}

export const authService = new AuthService();